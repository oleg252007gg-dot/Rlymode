package com.skilltree;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Monster;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/** Серверные события: пассивные навыки, бонусы боя, оружие, тики. */
public final class ServerLogic {
    /** true, пока мод сам наносит урон — чтобы бонусы не зацикливались. */
    public static boolean busy = false;

    private static final Map<UUID, Integer> SECOND_WIND = new HashMap<>();
    private static final Map<UUID, Float> LAST_EXHAUSTION = new HashMap<>();

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(ServerLogic::tick);
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> { Scheduler.clear(); PlayerSkills.clearAll(); SECOND_WIND.clear(); LAST_EXHAUSTION.clear(); });

        ServerLivingEntityEvents.ALLOW_DAMAGE.register(ServerLogic::allowDamage);
        ServerLivingEntityEvents.AFTER_DAMAGE.register(ServerLogic::afterDamage);
        ServerLivingEntityEvents.AFTER_DEATH.register(ServerLogic::afterDeath);
        ServerLivingEntityEvents.ALLOW_DEATH.register(ServerLogic::allowDeath);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.player;
            PlayerSkills.MANA.put(p.getUuid(), PlayerSkills.maxMana(p));
            PlayerSkills.applyStats(p);
            Net.sync(p);
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID id = handler.player.getUuid();
            PlayerSkills.MANA.remove(id); PlayerSkills.CD.remove(id);
            LAST_EXHAUSTION.remove(id);
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldP, newP, alive) -> {
            PlayerSkills.applyStats(newP);
            if (!alive) newP.setHealth(newP.getMaxHealth());
            PlayerSkills.MANA.put(newP.getUuid(), PlayerSkills.maxMana(newP));
            Net.sync(newP);
        });

        // ПКМ с уникальным оружием
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (!world.isClient && player instanceof ServerPlayerEntity sp) {
                String ab = ModItems.RIGHT_CLICK.get(player.getStackInHand(hand).getItem());
                if (ab != null) Abilities.cast(sp, ab, true);
            }
            return ActionResult.PASS;
        });
    }

    // ================================================================== тик
    private static void tick(MinecraftServer server) {
        Scheduler.tick();
        int t = server.getTicks();
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            Map<Stat, Double> st = PlayerSkills.stats(p);
            UUID id = p.getUuid();

            // мана
            float regen = (float) ((PlayerSkills.BASE_REGEN + st.getOrDefault(Stat.MANA_REGEN, 0.0)) / 20.0);
            PlayerSkills.addMana(p, regen);

            // экономия голода
            double hs = st.getOrDefault(Stat.HUNGER_SAVE, 0.0);
            float ex = p.getHungerManager().getExhaustion();
            Float last = LAST_EXHAUSTION.get(id);
            if (last != null && hs > 0 && ex > last) {
                p.getHungerManager().addExhaustion((float) (-(ex - last) * Math.min(hs, 0.8)));
                ex = p.getHungerManager().getExhaustion();
            }
            LAST_EXHAUSTION.put(id, ex);

            if (st.getOrDefault(Stat.MAGNET, 0.0) > 0 && t % 2 == 0) magnet(p, st.get(Stat.MAGNET));
            if (t % 20 == 0) passive(p, st, t);
            if (t % 10 == 0) Net.sync(p);
        }
    }

    private static void eff(ServerPlayerEntity p, RegistryEntry<StatusEffect> e, int dur, int amp) {
        p.addStatusEffect(new StatusEffectInstance(e, dur, amp, true, false, false));
    }

    private static void passive(ServerPlayerEntity p, Map<Stat, Double> st, int t) {
        if (st.isEmpty()) return;
        if (st.containsKey(Stat.NIGHT_VISION)) eff(p, StatusEffects.NIGHT_VISION, 400, 0);
        if (st.containsKey(Stat.WATER_BREATHING)) eff(p, StatusEffects.WATER_BREATHING, 100, 0);
        if (st.containsKey(Stat.FIRE_RES)) eff(p, StatusEffects.FIRE_RESISTANCE, 100, 0);
        int haste = (int) Math.round(st.getOrDefault(Stat.HASTE, 0.0));
        if (haste > 0) eff(p, StatusEffects.HASTE, 100, haste - 1);
        if (st.containsKey(Stat.IMMUNE_POISON)) p.removeStatusEffect(StatusEffects.POISON);
        if (st.containsKey(Stat.IMMUNE_WITHER)) p.removeStatusEffect(StatusEffects.WITHER);
        if (st.containsKey(Stat.IMMUNE_HUNGER)) p.removeStatusEffect(StatusEffects.HUNGER);
        double reg = st.getOrDefault(Stat.REGEN, 0.0);
        if (reg > 0 && p.isAlive() && p.getHealth() < p.getMaxHealth() && p.getHungerManager().getFoodLevel() >= 14) p.heal((float) reg);
        if (st.containsKey(Stat.SATURATION) && t % 100 == 0 && p.getHungerManager().getFoodLevel() < 20) {
            p.getHungerManager().setFoodLevel(p.getHungerManager().getFoodLevel() + 1);
        }
    }

    private static void magnet(ServerPlayerEntity p, double range) {
        Vec3d to = p.getPos().add(0, 0.6, 0);
        for (ItemEntity i : Fx.w(p).getEntitiesByClass(ItemEntity.class, p.getBoundingBox().expand(range), ItemEntity::isAlive)) {
            Vec3d d = to.subtract(i.getPos());
            if (d.lengthSquared() > 0.36) i.setVelocity(d.normalize().multiply(0.35));
        }
    }

    // ================================================================== урон
    private static boolean allowDamage(LivingEntity e, DamageSource src, float amount) {
        if (busy) return true;
        if (e instanceof ServerPlayerEntity p && src.getAttacker() != null) {
            double dodge = PlayerSkills.stat(p, Stat.DODGE);
            if (dodge > 0 && p.getRandom().nextDouble() < Math.min(dodge, 0.5)) {
                Fx.particles(Fx.w(p), ParticleTypes.CLOUD, p.getPos().add(0, 1, 0), 10, 0.3, 0.05);
                Fx.msg(p, "Уклонение!");
                return false;
            }
        }
        return true;
    }

    private static void afterDamage(LivingEntity victim, DamageSource src, float base, float taken, boolean blocked) {
        if (busy) return;
        if (victim instanceof ServerPlayerEntity vp) victimSide(vp, src, taken);
        if (!(src.getAttacker() instanceof ServerPlayerEntity p) || victim == p || !src.isOf(DamageTypes.PLAYER_ATTACK)) return;
        meleeSide(p, victim, base, taken);
    }

    private static void victimSide(ServerPlayerEntity vp, DamageSource src, float taken) {
        Map<Stat, Double> st = PlayerSkills.stats(vp);
        double ms = st.getOrDefault(Stat.MANA_SHIELD, 0.0);
        if (ms > 0 && taken > 0) {
            float use = Math.min((float) (taken * ms) * 2f, PlayerSkills.mana(vp));
            if (use > 0) {
                PlayerSkills.addMana(vp, -use);
                vp.heal(use / 2f);
                Fx.particles(Fx.w(vp), ParticleTypes.ENCHANT, vp.getPos().add(0, 1, 0), 10, 0.5, 0.3);
            }
        }
        double th = st.getOrDefault(Stat.THORNS, 0.0);
        if (th > 0 && src.getAttacker() instanceof LivingEntity att && att != vp
                && (src.isOf(DamageTypes.MOB_ATTACK) || src.isOf(DamageTypes.PLAYER_ATTACK))) {
            ServerWorld w = Fx.w(vp);
            busy = true;
            try {
                att.timeUntilRegen = 0;
                att.damage(w, w.getDamageSources().thorns(vp), (float) (taken * th));
            } finally { busy = false; }
        }
    }

    private static void meleeSide(ServerPlayerEntity p, LivingEntity victim, float base, float taken) {
        Map<Stat, Double> st = PlayerSkills.stats(p);
        ServerWorld w = Fx.w(p);
        Item held = p.getMainHandStack().getItem();
        double extra = 0;

        if (ModItems.isSpecial(held)) extra += base * st.getOrDefault(Stat.WEAPON_MASTERY, 0.0);

        double crit = st.getOrDefault(Stat.CRIT_CHANCE, 0.0);
        if (crit > 0 && p.getRandom().nextDouble() < crit) {
            extra += base * (0.5 + st.getOrDefault(Stat.CRIT_DAMAGE, 0.0));
            Fx.particles(w, ParticleTypes.CRIT, victim.getBoundingBox().getCenter(), 15, 0.4, 0.3);
        }
        double exec = st.getOrDefault(Stat.EXECUTE, 0.0);
        if (exec > 0 && victim.getHealth() <= victim.getMaxHealth() * 0.3f) extra += base * exec;
        extra += base * st.getOrDefault(Stat.ARMOR_PEN, 0.0);
        double bz = st.getOrDefault(Stat.BERSERK, 0.0);
        if (bz > 0) extra += base * bz * (1.0 - p.getHealth() / p.getMaxHealth());

        // ---- особенности оружия ----
        if (held == ModItems.DUAL_BLADES) {
            Scheduler.delay(w, 4, () -> {
                if (victim.isAlive()) {
                    Fx.phys(p, victim, base * 0.6);
                    Fx.particles(w, ParticleTypes.SWEEP_ATTACK, victim.getBoundingBox().getCenter(), 1, 0, 0);
                }
            });
        } else if (held == ModItems.DAGGER) {
            Vec3d tl = victim.getRotationVec(1f);
            Vec3d to = p.getPos().subtract(victim.getPos());
            if (to.lengthSquared() > 1e-4 && tl.dotProduct(to.normalize()) < -0.2) {
                extra += base;
                Fx.particles(w, ParticleTypes.CRIT, victim.getBoundingBox().getCenter(), 20, 0.3, 0.4);
                Fx.msg(p, "Удар в спину!");
            }
        } else if (held == ModItems.KATANA) {
            victim.setOnFireFor(4);
        } else if (held == ModItems.SPEAR) {
            Vec3d c = victim.getBoundingBox().getCenter();
            int n = 0;
            for (LivingEntity o : Fx.around(p, c, 4)) {
                if (o == victim || n >= 2) continue;
                n++;
                Fx.line(w, ParticleTypes.ELECTRIC_SPARK, c, o.getBoundingBox().getCenter(), 0.4);
                Fx.magic(p, o, base * 0.4);
            }
        } else if (held == ModItems.HAMMER) {
            Vec3d c = victim.getPos();
            Fx.particles(w, ParticleTypes.EXPLOSION, c.add(0, 0.5, 0), 1, 0, 0);
            Fx.ring(w, ParticleTypes.CLOUD, c, 2.5, 16, 0.2);
            for (LivingEntity o : Fx.around(p, c, 3)) {
                if (o == victim) continue;
                Fx.phys(p, o, base * 0.4);
                Fx.pushAway(o, c, 0.8, 0.3);
            }
            victim.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 2));
        } else if (held == ModItems.SCYTHE) {
            victim.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 60, 0));
            p.heal(taken * 0.15f);
        }

        if (extra > 0.01) Fx.phys(p, victim, extra);

        double ls = st.getOrDefault(Stat.LIFESTEAL, 0.0);
        if (ls > 0) p.heal((float) ((taken + extra) * ls));

        double bleed = st.getOrDefault(Stat.BLEED, 0.0);
        if (bleed > 0 && p.getRandom().nextDouble() < bleed) {
            Scheduler.add(w, 61, age -> {
                if (!victim.isAlive()) return true;
                if (age > 0 && age % 12 == 0) {
                    Fx.magic(p, victim, 1.5);
                    Fx.particles(w, ParticleTypes.DAMAGE_INDICATOR, victim.getBoundingBox().getCenter(), 3, 0.2, 0.1);
                }
                return false;
            });
        }
    }

    private static void afterDeath(LivingEntity e, DamageSource src) {
        if (src.getAttacker() instanceof ServerPlayerEntity p && e != p) {
            double kh = PlayerSkills.stat(p, Stat.KILL_HEAL);
            if (kh > 0) p.heal((float) kh);
            if (PlayerSkills.stat(p, Stat.KILL_SPEED) > 0) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 80, 1));
            }
            if (e instanceof Monster) PlayerSkills.addKill(p);
        }
    }

    private static boolean allowDeath(LivingEntity e, DamageSource src, float amount) {
        if (e instanceof ServerPlayerEntity p && PlayerSkills.stat(p, Stat.SECOND_WIND) > 0 && p.getServer() != null) {
            int now = p.getServer().getTicks();
            Integer last = SECOND_WIND.get(p.getUuid());
            if (last == null || now - last > 6000) {
                SECOND_WIND.put(p.getUuid(), now);
                p.setHealth(Math.min(p.getMaxHealth(), 10f));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 100, 3));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 200, 2));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100, 2));
                Fx.particles(Fx.w(p), ParticleTypes.TOTEM_OF_UNDYING, p.getPos().add(0, 1, 0), 40, 0.5, 0.4);
                Fx.sound(Fx.w(p), p.getPos(), SoundEvents.ITEM_TOTEM_USE, 1f, 1f);
                Fx.msg(p, "Второе дыхание!");
                return false;
            }
        }
        return true;
    }
}
