package com.skilltree;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributeModifier.Operation;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Уникальное оружие боевой ветки. Текстуры: assets/skilltree/textures/item/*.png */
public final class ModItems {
    public static Item DUAL_BLADES, DAGGER, KATANA, SPEAR, HAMMER, SCYTHE;

    private static final List<Item> SPECIAL = new ArrayList<>();
    /** ПКМ с оружием -> способность (работает без изучения самой способности). */
    public static final Map<Item, String> RIGHT_CLICK = new HashMap<>();

    public static boolean isSpecial(Item i) { return SPECIAL.contains(i); }

    public static void init() {
        //                 id               урон  скорость  доп.дальность
        DUAL_BLADES = weapon("dual_blades",   5.0, 2.8, 0.0, Rarity.RARE);
        DAGGER      = weapon("shadow_dagger", 3.5, 3.6, 0.0, Rarity.UNCOMMON);
        KATANA      = weapon("rage_katana",   7.0, 1.8, 0.3, Rarity.RARE);
        SPEAR       = weapon("storm_spear",   6.5, 1.4, 1.5, Rarity.RARE);
        HAMMER      = weapon("titan_hammer", 12.0, 0.9, 0.0, Rarity.EPIC);
        SCYTHE      = weapon("reaper_scythe", 8.5, 1.2, 0.8, Rarity.EPIC);

        RIGHT_CLICK.put(DUAL_BLADES, "whirlwind");
        RIGHT_CLICK.put(DAGGER, "shadow_step");
        RIGHT_CLICK.put(KATANA, "dash");
        RIGHT_CLICK.put(SPEAR, "blade_throw");
        RIGHT_CLICK.put(HAMMER, "leap_slam");
        RIGHT_CLICK.put(SCYTHE, "crushing_blow");

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> SPECIAL.forEach(entries::add));
    }

    private static Item weapon(String name, double dmg, double speed, double reach, Rarity rarity) {
        Identifier id = Identifier.of(SkillTreeMod.MOD_ID, name);
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);

        AttributeModifiersComponent.Builder b = AttributeModifiersComponent.builder();
        b.add(AttrUtil.get("attack_damage"),
                new EntityAttributeModifier(Identifier.ofVanilla("base_attack_damage"), dmg - 1.0, Operation.ADD_VALUE),
                AttributeModifierSlot.MAINHAND);
        b.add(AttrUtil.get("attack_speed"),
                new EntityAttributeModifier(Identifier.ofVanilla("base_attack_speed"), speed - 4.0, Operation.ADD_VALUE),
                AttributeModifierSlot.MAINHAND);
        if (reach > 0) {
            b.add(AttrUtil.get("entity_interaction_range"),
                    new EntityAttributeModifier(Identifier.of(SkillTreeMod.MOD_ID, "reach_" + name), reach, Operation.ADD_VALUE),
                    AttributeModifierSlot.MAINHAND);
        }

        Item item = new Item(new Item.Settings()
                .registryKey(key)
                .maxCount(1)
                .rarity(rarity)
                .attributeModifiers(b.build()));
        Registry.register(Registries.ITEM, key, item);
        SPECIAL.add(item);
        return item;
    }
}
