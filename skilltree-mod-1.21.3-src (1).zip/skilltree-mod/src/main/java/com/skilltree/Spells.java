package com.skilltree;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Реализация всех способностей. */
final class Spells {
    private Spells() {}

    private static void eff(LivingEntity e, RegistryEntry<StatusEffect> t, int dur, int amp) {
        e.addStatusEffect(new StatusEffectInstance(t, dur, amp));
    }
    private static boolean gone(ServerPlayerEntity p) { return !p.isAlive() || p.isRemoved(); }

    // ================================================================== МАГИЯ: ОГОНЬ
    static boolean fireball(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Vec3d dir = p.getRotationVec(1f);
        Vec3d[] pos = { p.getEyePos().add(dir.multiply(1.2)).add(0, -0.2, 0) };
        double dmg = 7 * Fx.fire(p);
        Fx.sound(w, pos[0], SoundEvents.ENTITY_BLAZE_SHOOT, 1f, 0.8f);
        Scheduler.add(w, 60, age -> {
            for (int i = 0; i < 2; i++) {
                pos[0] = pos[0].add(dir.multiply(0.8));
                Fx.particles(w, ParticleTypes.FLAME, pos[0], 6, 0.12, 0.01);
                Fx.particles(w, ParticleTypes.SMOKE, pos[0], 2, 0.1, 0);
                BlockPos bp = BlockPos.ofFloored(pos[0]);
                boolean wall = !w.getBlockState(bp).getCollisionShape(w, bp).isEmpty();
                if (wall || !Fx.around(p, pos[0], 1.1).isEmpty()) {
                    Fx.explode(p, pos[0], 3.5, dmg, true);
                    return true;
                }
            }
            return false;
        });
        return true;
    }

    /** Стена огня или льда. */
    static boolean wall(ServerPlayerEntity p, boolean fire) {
        ServerWorld w = Fx.w(p);
        Vec3d c = Fx.aim(p, 24);
        Vec3d look = p.getRotationVec(1f);
        Vec3d f = new Vec3d(look.x, 0, look.z);
        f = f.lengthSquared() < 1e-4 ? new Vec3d(0, 0, 1) : f.normalize();
        final Vec3d fw = f;
        final Vec3d side = new Vec3d(-f.z, 0, f.x);
        double dmg = fire ? 3 * Fx.fire(p) : 2 * Fx.frost(p);
        ParticleEffect main = fire ? ParticleTypes.FLAME : ParticleTypes.SNOWFLAKE;
        ParticleEffect extra = fire ? ParticleTypes.SMOKE : ParticleTypes.CLOUD;
        Fx.sound(w, c, fire ? SoundEvents.ENTITY_BLAZE_SHOOT : SoundEvents.BLOCK_GLASS_BREAK, 1f, 0.7f);
        Scheduler.add(w, 160, age -> {
            if (age % 2 == 0) {
                for (double s = -4.5; s <= 4.5; s += 0.75) {
                    Vec3d b = c.add(side.multiply(s));
                    Fx.particles(w, main, b.add(0, 0.2 + Math.random() * 2.6, 0), 2, 0.1, 0.01);
                    if (Math.random() < 0.25) Fx.particles(w, extra, b.add(0, 2.8, 0), 1, 0.1, 0.01);
                }
            }
            if (age % 10 == 0) {
                for (LivingEntity e : Fx.around(p, c.add(0, 1.5, 0), 7)) {
                    Vec3d d = e.getPos().subtract(c);
                    if (Math.abs(d.dotProduct(side)) <= 5.2 && Math.abs(d.dotProduct(fw)) <= 1.4 && d.y > -1.2 && d.y < 3.6) {
                        Fx.magic(p, e, dmg);
                        if (fire) e.setOnFireFor(4);
                        else { eff(e, StatusEffects.SLOWNESS, 50, 3); e.setFrozenTicks(120); }
                    }
                }
            }
            return gone(p);
        });
        return true;
    }

    static boolean nova(ServerPlayerEntity p, boolean fire) {
        ServerWorld w = Fx.w(p);
        Vec3d c = p.getPos();
        double r = 7;
        ParticleEffect pt = fire ? ParticleTypes.FLAME : ParticleTypes.SNOWFLAKE;
        Fx.sound(w, c, fire ? SoundEvents.ENTITY_BLAZE_SHOOT : SoundEvents.BLOCK_GLASS_BREAK, 1.2f, 0.6f);
        Scheduler.add(w, 8, age -> {
            Fx.ring(w, pt, c, r * (age + 1) / 8.0, 36, 0.2);
            return false;
        });
        for (LivingEntity t : Fx.around(p, c, r)) {
            if (fire) { Fx.magic(p, t, 8 * Fx.fire(p)); t.setOnFireFor(5); Fx.pushAway(t, c, 0.8, 0.4); }
            else { Fx.magic(p, t, 5 * Fx.frost(p)); t.setFrozenTicks(240); eff(t, StatusEffects.SLOWNESS, 100, 3); }
        }
        return true;
    }

    static boolean meteor(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Vec3d tgt = Fx.aim(p, 45);
        double dmg = 22 * Fx.fire(p);
        Fx.sound(w, tgt, SoundEvents.ENTITY_WITHER_SHOOT, 1.5f, 0.5f);
        Scheduler.add(w, 41, age -> {
            if (age % 2 == 0) Fx.ring(w, ParticleTypes.FLAME, tgt, 5.5, 20, 0.15);
            double h = 32 * (1.0 - Math.min(1.0, age / 40.0));
            Vec3d m = tgt.add(h * 0.25, h, h * 0.25);
            Fx.particles(w, ParticleTypes.FLAME, m, 14, 0.5, 0.03);
            Fx.particles(w, ParticleTypes.LARGE_SMOKE, m, 6, 0.5, 0.02);
            Fx.particles(w, ParticleTypes.LAVA, m, 2, 0.4, 0);
            if (age == 40) {
                Fx.particles(w, ParticleTypes.EXPLOSION_EMITTER, tgt.add(0, 1, 0), 1, 0, 0);
                Fx.particles(w, ParticleTypes.LAVA, tgt.add(0, 1, 0), 30, 2.5, 0);
                Fx.explode(p, tgt, 7, dmg, true);
                return true;
            }
            return false;
        });
        return true;
    }

    // ================================================================== МАГИЯ: ЛЁД
    static boolean iceShard(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        List<LivingEntity> hit = Fx.ray(p, 24, 0.4, 3);
        if (hit.isEmpty()) { Fx.msg(p, "Нет цели"); return false; }
        Vec3d from = p.getEyePos().add(0, -0.25, 0);
        Fx.line(w, ParticleTypes.SNOWFLAKE, from, hit.get(hit.size() - 1).getBoundingBox().getCenter(), 0.4);
        Fx.sound(w, from, SoundEvents.BLOCK_GLASS_BREAK, 1f, 1.6f);
        for (LivingEntity t : hit) {
            Fx.magic(p, t, 8 * Fx.frost(p));
            t.setFrozenTicks(180);
            eff(t, StatusEffects.SLOWNESS, 80, 2);
            Fx.particles(w, ParticleTypes.SNOWFLAKE, t.getBoundingBox().getCenter(), 15, 0.4, 0.05);
        }
        return true;
    }

    static boolean hail(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Vec3d c = Fx.aim(p, 30);
        double dmg = 5 * Fx.frost(p);
        Fx.sound(w, c, SoundEvents.BLOCK_GLASS_BREAK, 1.2f, 0.6f);
        Scheduler.add(w, 100, age -> {
            if (age % 6 == 0) Fx.ring(w, ParticleTypes.SNOWFLAKE, c, 6, 24, 0.2);
            if (age % 2 == 0) {
                for (int i = 0; i < 2; i++) {
                    double a = Math.random() * Math.PI * 2, r = Math.sqrt(Math.random()) * 6;
                    Vec3d g = c.add(Math.cos(a) * r, 0, Math.sin(a) * r);
                    for (int h = 0; h < 10; h++) Fx.particles(w, ParticleTypes.SNOWFLAKE, g.add(0, h, 0), 1, 0.05, 0);
                    Fx.particles(w, ParticleTypes.CLOUD, g, 4, 0.2, 0.02);
                    for (LivingEntity t : Fx.around(p, g.add(0, 1, 0), 1.8)) {
                        Fx.magic(p, t, dmg);
                        eff(t, StatusEffects.SLOWNESS, 60, 1);
                        t.setFrozenTicks(80);
                    }
                }
            }
            return gone(p);
        });
        return true;
    }

    // ================================================================== МАГИЯ: АРКАНУМ / ТЬМА
    static boolean stream(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Scheduler.add(w, 60, age -> {
            if (gone(p)) return true;
            Vec3d from = p.getEyePos().add(p.getRotationVec(1f).multiply(0.8)).add(0, -0.25, 0);
            Fx.line(w, ParticleTypes.END_ROD, from, Fx.rayEnd(p, 14), 0.5);
            if (age % 3 == 0) Fx.line(w, ParticleTypes.WITCH, from, Fx.rayEnd(p, 14), 1.2);
            if (age % 4 == 0) {
                for (LivingEntity t : Fx.ray(p, 14, 0.6, 6)) {
                    Fx.magic(p, t, 2.5 * Fx.sp(p));
                    Fx.particles(w, ParticleTypes.ENCHANT, t.getBoundingBox().getCenter(), 8, 0.4, 0.2);
                }
            }
            if (age % 10 == 0) Fx.sound(w, from, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
            return false;
        });
        return true;
    }

    static boolean decay(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        double r = 5;
        Fx.sound(w, p.getPos(), SoundEvents.ENTITY_EVOKER_CAST_SPELL, 1f, 0.5f);
        Scheduler.add(w, 200, age -> {
            if (gone(p)) return true;
            Vec3d c = p.getPos();
            for (int i = 0; i < 10; i++) {
                double a = age * 0.15 + i * Math.PI / 5;
                Vec3d b = c.add(Math.cos(a) * r, 0.1 + (i % 3) * 0.5, Math.sin(a) * r);
                Fx.particles(w, ParticleTypes.SCULK_SOUL, b, 1, 0.05, 0.01);
                if (i % 2 == 0) Fx.particles(w, ParticleTypes.SMOKE, b, 1, 0.2, 0.01);
            }
            if (age % 20 == 0) {
                for (LivingEntity t : Fx.around(p, c, r)) {
                    Fx.magic(p, t, 2.5 * Fx.sp(p));
                    eff(t, StatusEffects.WITHER, 60, 1);
                    eff(t, StatusEffects.WEAKNESS, 60, 0);
                }
            }
            return false;
        });
        return true;
    }

    static boolean drain(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        List<LivingEntity> hit = Fx.ray(p, 14, 0.5, 1);
        if (hit.isEmpty()) { Fx.msg(p, "Нет цели"); return false; }
        LivingEntity t = hit.get(0);
        Vec3d to = t.getBoundingBox().getCenter();
        Fx.line(w, ParticleTypes.SOUL, to, p.getEyePos().add(0, -0.4, 0), 0.35);
        Fx.magic(p, t, 6 * Fx.sp(p));
        p.heal((float) (4 * Fx.sp(p)));
        Fx.particles(w, ParticleTypes.HEART, p.getPos().add(0, 1.8, 0), 4, 0.3, 0);
        Fx.sound(w, to, SoundEvents.ENTITY_ZOMBIE_VILLAGER_CURE, 0.7f, 1.6f);
        return true;
    }

    static boolean blackHole(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Vec3d c = Fx.aim(p, 28).add(0, 1.5, 0);
        double dmg = 3 * Fx.sp(p);
        Fx.sound(w, c, SoundEvents.ENTITY_WITHER_SHOOT, 1.2f, 0.4f);
        Scheduler.add(w, 81, age -> {
            for (int i = 0; i < 8; i++) {
                double a = age * 0.4 + i * Math.PI / 4, rr = 2.5 - 2.0 * (age % 20) / 20.0;
                Fx.particles(w, ParticleTypes.PORTAL, c.add(Math.cos(a) * rr, Math.sin(a * 0.7) * 0.8, Math.sin(a) * rr), 2, 0.1, 0.1);
            }
            Fx.particles(w, ParticleTypes.SMOKE, c, 4, 0.3, 0.02);
            for (LivingEntity e : Fx.around(p, c, 9)) {
                Vec3d d = c.subtract(e.getBoundingBox().getCenter());
                if (d.length() > 0.6) {
                    e.setVelocity(e.getVelocity().multiply(0.6).add(d.normalize().multiply(0.22)));
                    e.velocityModified = true;
                }
                if (age % 10 == 0) Fx.magic(p, e, dmg);
            }
            if (age == 80) {
                Fx.particles(w, ParticleTypes.EXPLOSION, c, 3, 1.5, 0);
                Fx.sound(w, c, SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, 1.2f, 0.6f);
                for (LivingEntity e : Fx.around(p, c, 5)) { Fx.magic(p, e, 8 * Fx.sp(p)); Fx.pushAway(e, c, 0.9, 0.4); }
                return true;
            }
            return false;
        });
        return true;
    }

    // ================================================================== МАГИЯ: БУРЯ
    static boolean chain(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        List<LivingEntity> first = Fx.ray(p, 24, 0.5, 1);
        if (first.isEmpty()) { Fx.msg(p, "Нет цели"); return false; }
        LivingEntity cur = first.get(0);
        Set<LivingEntity> seen = new HashSet<>();
        Vec3d from = p.getEyePos().add(0, -0.3, 0);
        double dmg = 7 * Fx.sp(p);
        Fx.sound(w, from, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, 1.6f);
        for (int i = 0; i < 6 && cur != null; i++) {
            seen.add(cur);
            Vec3d to = cur.getBoundingBox().getCenter();
            Fx.line(w, ParticleTypes.ELECTRIC_SPARK, from, to, 0.35);
            Fx.magic(p, cur, dmg);
            eff(cur, StatusEffects.SLOWNESS, 30, 4);
            dmg *= 0.85;
            from = to;
            LivingEntity next = null;
            double best = Double.MAX_VALUE;
            for (LivingEntity e : Fx.around(p, to, 7)) {
                if (seen.contains(e)) continue;
                double d = e.squaredDistanceTo(to);
                if (d < best) { best = d; next = e; }
            }
            cur = next;
        }
        return true;
    }

    static boolean blink(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Vec3d start = p.getPos();
        Vec3d look = p.getRotationVec(1f);
        Vec3d end = Fx.rayEnd(p, 14);
        Vec3d dest = end.subtract(p.getEyePos()).length() < 14 ? end.subtract(look.multiply(0.7)) : end;
        dest = dest.add(0, -p.getEyeHeight(p.getPose()), 0);
        Vec3d step = start.subtract(dest);
        for (int i = 0; i < 14; i++) {
            Box moved = p.getBoundingBox().offset(dest.subtract(start));
            if (w.isSpaceEmpty(p, moved)) break;
            double l = step.length();
            if (l < 0.5) { Fx.msg(p, "Нет места"); return false; }
            dest = dest.add(step.normalize().multiply(0.7));
        }
        Fx.particles(w, ParticleTypes.PORTAL, start.add(0, 1, 0), 40, 0.4, 0.5);
        p.networkHandler.requestTeleport(dest.x, dest.y, dest.z, p.getYaw(), p.getPitch());
        p.fallDistance = 0;
        Fx.particles(w, ParticleTypes.PORTAL, dest.add(0, 1, 0), 40, 0.4, 0.5);
        Fx.sound(w, dest, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
        return true;
    }

    static boolean shockwave(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Vec3d c = p.getPos();
        Fx.sound(w, c, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 0.8f, 1.4f);
        Scheduler.add(w, 6, age -> { Fx.ring(w, ParticleTypes.CLOUD, c, 7.0 * (age + 1) / 6, 36, 0.3); return false; });
        Fx.particles(w, ParticleTypes.EXPLOSION, c.add(0, 1, 0), 3, 1.0, 0);
        for (LivingEntity t : Fx.around(p, c, 7)) { Fx.magic(p, t, 6 * Fx.sp(p)); Fx.pushAway(t, c, 1.6, 0.55); }
        return true;
    }

    static boolean timeWarp(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Vec3d c = p.getPos();
        Fx.sound(w, c, SoundEvents.BLOCK_BEACON_ACTIVATE, 1.2f, 0.5f);
        Scheduler.add(w, 160, age -> {
            if (age % 4 == 0) Fx.ring(w, ParticleTypes.END_ROD, p.getPos(), 10, 30, 0.2 + (age % 40) / 20.0);
            return gone(p);
        });
        for (LivingEntity t : Fx.around(p, c, 10)) { eff(t, StatusEffects.SLOWNESS, 160, 5); eff(t, StatusEffects.WEAKNESS, 160, 1); }
        eff(p, StatusEffects.SPEED, 160, 2);
        eff(p, StatusEffects.HASTE, 160, 2);
        return true;
    }

    // ================================================================== МАГИЯ: ЖИЗНЬ
    static boolean heal(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        p.heal((float) (10 * Fx.sp(p)));
        eff(p, StatusEffects.REGENERATION, 100, 1);
        Fx.particles(w, ParticleTypes.HEART, p.getPos().add(0, 1.5, 0), 10, 0.5, 0);
        Fx.sound(w, p.getPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, 0.7f, 1.8f);
        for (ServerPlayerEntity o : w.getEntitiesByClass(ServerPlayerEntity.class, p.getBoundingBox().expand(8), x -> x != p && x.isAlive())) {
            o.heal(6f);
            eff(o, StatusEffects.REGENERATION, 60, 0);
            Fx.particles(w, ParticleTypes.HEART, o.getPos().add(0, 1.5, 0), 6, 0.4, 0);
        }
        return true;
    }

    static boolean barrier(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        eff(p, StatusEffects.ABSORPTION, 400, 3);
        eff(p, StatusEffects.RESISTANCE, 400, 1);
        Fx.ring(w, ParticleTypes.ENCHANT, p.getPos(), 1.2, 24, 1.0);
        Fx.particles(w, ParticleTypes.ENCHANT, p.getPos().add(0, 1, 0), 40, 0.8, 0.5);
        Fx.sound(w, p.getPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, 1f, 1.4f);
        return true;
    }

    static boolean poisonCloud(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Vec3d c = Fx.aim(p, 20);
        Fx.sound(w, c, SoundEvents.ENTITY_EVOKER_CAST_SPELL, 1f, 0.6f);
        Scheduler.add(w, 160, age -> {
            Fx.particles(w, ParticleTypes.HAPPY_VILLAGER, c.add(0, 0.8, 0), 6, 1.8, 0.02);
            Fx.particles(w, ParticleTypes.SPORE_BLOSSOM_AIR, c.add(0, 1.2, 0), 10, 2.0, 0.01);
            if (age % 10 == 0) {
                for (LivingEntity t : Fx.around(p, c.add(0, 1, 0), 4)) {
                    Fx.magic(p, t, 1.0 * Fx.sp(p));
                    eff(t, StatusEffects.POISON, 60, 1);
                }
            }
            return gone(p);
        });
        return true;
    }

    // ================================================================== БОЙ
    static boolean dash(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Vec3d look = p.getRotationVec(1f);
        Vec3d v = new Vec3d(look.x, Math.max(0.05, look.y * 0.3), look.z).normalize().multiply(1.7);
        p.setVelocity(v);
        p.velocityModified = true;
        p.fallDistance = 0;
        double dmg = Fx.atk(p) * 1.2;
        Set<LivingEntity> hit = new HashSet<>();
        Fx.sound(w, p.getPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 1.5f);
        Scheduler.add(w, 8, age -> {
            Fx.particles(w, ParticleTypes.CLOUD, p.getPos().add(0, 0.5, 0), 6, 0.2, 0.02);
            Fx.particles(w, ParticleTypes.CRIT, p.getPos().add(0, 1, 0), 4, 0.3, 0.1);
            for (LivingEntity t : Fx.around(p, p.getPos().add(0, 1, 0), 1.9)) {
                if (hit.add(t)) { Fx.phys(p, t, dmg); Fx.pushAway(t, p.getPos(), 0.5, 0.25); }
            }
            return gone(p);
        });
        return true;
    }

    static boolean whirlwind(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        double dmg = Fx.atk(p) * 0.9;
        Fx.sound(w, p.getPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.2f, 0.8f);
        Scheduler.add(w, 15, age -> {
            if (gone(p)) return true;
            Vec3d c = p.getPos();
            Fx.ring(w, ParticleTypes.SWEEP_ATTACK, c, 2.5, 5, 1.0);
            if (age % 5 == 0) {
                Fx.sound(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 0.8f, 1f);
                for (LivingEntity t : Fx.around(p, c, 3.6)) { Fx.phys(p, t, dmg); Fx.pushAway(t, c, 0.35, 0.15); }
            }
            return false;
        });
        return true;
    }

    static boolean warCry(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        eff(p, StatusEffects.STRENGTH, 300, 1);
        eff(p, StatusEffects.SPEED, 300, 0);
        Fx.sound(w, p.getPos(), SoundEvents.ENTITY_RAVAGER_ROAR, 1.2f, 0.8f);
        Fx.ring(w, ParticleTypes.ANGRY_VILLAGER, p.getPos(), 3, 12, 1.5);
        for (LivingEntity t : Fx.around(p, p.getPos(), 9)) { eff(t, StatusEffects.WEAKNESS, 200, 0); Fx.pushAway(t, p.getPos(), 0.6, 0.15); }
        return true;
    }

    static boolean leapSlam(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Vec3d look = p.getRotationVec(1f);
        p.setVelocity(look.x * 1.0, 0.95, look.z * 1.0);
        p.velocityModified = true;
        double dmg = Fx.atk(p) * 1.8;
        Fx.sound(w, p.getPos(), SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1f, 0.7f);
        Scheduler.add(w, 80, age -> {
            if (gone(p)) return true;
            p.fallDistance = 0;
            if (age >= 6 && p.isOnGround()) {
                Vec3d c = p.getPos();
                Fx.particles(w, ParticleTypes.EXPLOSION, c.add(0, 0.5, 0), 3, 1.5, 0);
                Fx.ring(w, ParticleTypes.CLOUD, c, 4, 30, 0.2);
                Fx.sound(w, c, SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, 1f, 0.8f);
                for (LivingEntity t : Fx.around(p, c, 5.5)) { Fx.phys(p, t, dmg); Fx.pushAway(t, c, 1.0, 0.5); }
                return true;
            }
            return false;
        });
        return true;
    }

    static boolean bladeThrow(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        List<LivingEntity> hit = Fx.ray(p, 20, 0.6, 5);
        Vec3d from = p.getEyePos().add(0, -0.3, 0);
        Fx.line(w, ParticleTypes.CRIT, from, Fx.rayEnd(p, 20), 0.5);
        Fx.sound(w, from, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 1.6f);
        if (hit.isEmpty()) { Fx.msg(p, "Нет цели"); return false; }
        for (LivingEntity t : hit) {
            Fx.phys(p, t, Fx.atk(p) * 1.4);
            Fx.particles(w, ParticleTypes.SWEEP_ATTACK, t.getBoundingBox().getCenter(), 1, 0, 0);
        }
        return true;
    }

    static boolean bloodRage(ServerPlayerEntity p) {
        if (p.getHealth() <= 6f) { Fx.msg(p, "Слишком мало здоровья"); return false; }
        ServerWorld w = Fx.w(p);
        p.setHealth(p.getHealth() - 4f);
        eff(p, StatusEffects.STRENGTH, 160, 2);
        eff(p, StatusEffects.SPEED, 160, 1);
        Fx.particles(w, ParticleTypes.ANGRY_VILLAGER, p.getPos().add(0, 1.8, 0), 8, 0.5, 0);
        Fx.sound(w, p.getPos(), SoundEvents.ENTITY_RAVAGER_ROAR, 1f, 1.2f);
        return true;
    }

    static boolean crushing(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        Vec3d c = p.getPos();
        Vec3d look = p.getRotationVec(1f);
        Vec3d fl = new Vec3d(look.x, 0, look.z);
        fl = fl.lengthSquared() < 1e-4 ? new Vec3d(0, 0, 1) : fl.normalize();
        double dmg = Fx.atk(p) * 2.2;
        Fx.sound(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.2f, 0.6f);
        for (int i = 1; i <= 4; i++) Fx.particles(w, ParticleTypes.SWEEP_ATTACK, c.add(fl.multiply(i)).add(0, 1, 0), 1, 0.3, 0);
        for (LivingEntity t : Fx.around(p, c, 4.5)) {
            Vec3d d = t.getPos().subtract(c);
            Vec3d dh = new Vec3d(d.x, 0, d.z);
            if (dh.lengthSquared() > 1e-4 && fl.dotProduct(dh.normalize()) < 0.5) continue;
            Fx.phys(p, t, dmg);
            Fx.push(t, new Vec3d(fl.x * 1.4, 0.4, fl.z * 1.4));
            eff(t, StatusEffects.WEAKNESS, 100, 0);
        }
        return true;
    }

    static boolean stoneSkin(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        eff(p, StatusEffects.RESISTANCE, 160, 2);
        eff(p, StatusEffects.ABSORPTION, 160, 1);
        Fx.particles(w, ParticleTypes.CLOUD, p.getPos().add(0, 1, 0), 20, 0.5, 0.02);
        Fx.sound(w, p.getPos(), SoundEvents.BLOCK_ANVIL_LAND, 0.7f, 1.2f);
        return true;
    }

    static boolean shadowStep(ServerPlayerEntity p) {
        ServerWorld w = Fx.w(p);
        List<LivingEntity> l = Fx.ray(p, 16, 1.0, 1);
        LivingEntity t = l.isEmpty() ? null : l.get(0);
        if (t == null) {
            double best = Double.MAX_VALUE;
            for (LivingEntity e : Fx.around(p, p.getPos(), 10)) {
                double d = e.squaredDistanceTo(p);
                if (d < best) { best = d; t = e; }
            }
        }
        if (t == null) { Fx.msg(p, "Нет цели"); return false; }
        Vec3d tl = new Vec3d(t.getRotationVec(1f).x, 0, t.getRotationVec(1f).z);
        tl = tl.lengthSquared() < 1e-3 ? new Vec3d(0, 0, 1) : tl.normalize();
        Vec3d dest = t.getPos().subtract(tl.multiply(1.4));
        if (!w.isSpaceEmpty(p, p.getBoundingBox().offset(dest.subtract(p.getPos())))) { Fx.msg(p, "Нет места"); return false; }
        Fx.particles(w, ParticleTypes.PORTAL, p.getPos().add(0, 1, 0), 30, 0.4, 0.4);
        p.networkHandler.requestTeleport(dest.x, dest.y, dest.z, t.getYaw(), 0f);
        p.fallDistance = 0;
        Fx.particles(w, ParticleTypes.PORTAL, dest.add(0, 1, 0), 30, 0.4, 0.4);
        Fx.sound(w, dest, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1f, 1.4f);
        Fx.phys(p, t, Fx.atk(p) * 2.0);
        Fx.particles(w, ParticleTypes.CRIT, t.getBoundingBox().getCenter(), 15, 0.3, 0.3);
        eff(p, StatusEffects.INVISIBILITY, 60, 0);
        return true;
    }
}
