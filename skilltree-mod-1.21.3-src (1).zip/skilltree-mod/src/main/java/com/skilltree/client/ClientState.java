package com.skilltree.client;

import com.skilltree.Net;
import com.skilltree.Skill;
import com.skilltree.Skills;

import java.util.*;

/** Клиентская копия данных игрока (приходит с сервера). */
public final class ClientState {
    public static int points, mana, maxMana = 100;
    public static final Set<String> unlocked = new HashSet<>();
    public static final Map<String, Long> cdEnd = new HashMap<>();
    public static long tick;
    public static int selected;

    public static void apply(Net.SyncPayload p) {
        points = p.points(); mana = p.mana(); maxMana = p.maxMana();
        unlocked.clear();
        if (!p.unlocked().isEmpty()) unlocked.addAll(Arrays.asList(p.unlocked().split(",")));
        cdEnd.clear();
        for (String e : p.cooldowns().split(";")) {
            if (e.isEmpty()) continue;
            String[] kv = e.split("=");
            try { cdEnd.put(kv[0], tick + Integer.parseInt(kv[1])); } catch (Exception ignored) { }
        }
    }

    public static void clear() { points = 0; mana = 0; unlocked.clear(); cdEnd.clear(); selected = 0; }

    /** Изученные активные способности в порядке дерева. */
    public static List<Skill> abilities() {
        List<Skill> r = new ArrayList<>();
        for (Skill s : Skills.ALL) if (s.ability != null && unlocked.contains(s.id)) r.add(s);
        return r;
    }

    public static int cdLeft(String abilityId) {
        Long end = cdEnd.get(abilityId);
        return end == null ? 0 : (int) Math.max(0, end - tick);
    }
}
