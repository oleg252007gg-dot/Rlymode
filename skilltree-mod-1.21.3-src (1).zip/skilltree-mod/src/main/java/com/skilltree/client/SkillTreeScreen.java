package com.skilltree.client;

import com.skilltree.Abilities;
import com.skilltree.Branch;
import com.skilltree.Net;
import com.skilltree.Skill;
import com.skilltree.Skills;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

public class SkillTreeScreen extends Screen {
    private static final int NODE = 28, SX = 46, SY = 44;
    private static Branch lastTab = Branch.MAGIC;

    private Branch tab = lastTab;
    private final double[] offX = new double[3], offY = new double[3];
    private boolean dragging;
    private int px, py, pw, ph, tx, ty, tw, th;

    private record Btn(int x, int y, int w, int h, String label, int color, Runnable run) {
        boolean hit(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }
    private record L(String t, int c) {}
    private final List<Btn> btns = new ArrayList<>();

    public SkillTreeScreen() { super(Text.literal("Древо навыков")); }

    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext c, int mx, int my, float d) { /* свой фон в render() */ }

    private static int mul(int rgb, double f) {
        int r = (int) (((rgb >> 16) & 255) * f), g = (int) (((rgb >> 8) & 255) * f), b = (int) ((rgb & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static void send(String a, String arg) { ClientPlayNetworking.send(new Net.ActionPayload(a, arg)); }

    private int nx(Skill s) {
        double mid = (Skills.minCol(tab) + Skills.maxCol(tab)) / 2.0;
        return (int) (tx + tw / 2.0 + offX[tab.ordinal()] + (s.col - mid) * SX);
    }
    private int ny(Skill s) { return (int) (ty + 28 + offY[tab.ordinal()] + s.row * SY); }

    private boolean inTree(double mx, double my) { return mx >= tx && mx < tx + tw && my >= ty && my < ty + th; }

    private Skill hovered(double mx, double my) {
        if (!inTree(mx, my)) return null;
        for (Skill s : Skills.of(tab)) {
            if (Math.abs(mx - nx(s)) <= NODE / 2.0 && Math.abs(my - ny(s)) <= NODE / 2.0) return s;
        }
        return null;
    }

    private void clampOffsets() {
        int i = tab.ordinal();
        double spanX = (Skills.maxCol(tab) - Skills.minCol(tab)) * SX / 2.0 + 40;
        offX[i] = MathHelper.clamp(offX[i], -spanX, spanX);
        double maxUp = Math.max(0, 28 + Skills.maxRow(tab) * SY + 30 - th);
        offY[i] = MathHelper.clamp(offY[i], -maxUp, 20);
    }

    // ------------------------------------------------------------------ рендер
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        pw = Math.min(width - 16, 640);
        ph = Math.min(height - 16, 420);
        px = (width - pw) / 2; py = (height - ph) / 2;
        tx = px + 6; ty = py + 52; tw = pw - 12; th = ph - 52 - 22;
        clampOffsets();

        ctx.fill(0, 0, width, height, 0xC00A0A12);
        ctx.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, mul(tab.rgb, 0.65));
        ctx.fillGradient(px, py, px + pw, py + ph, 0xFF1B1B2B, 0xFF0E0E17);

        // --- шапка ---
        ctx.drawTextWithShadow(textRenderer, "ДРЕВО НАВЫКОВ", px + 10, py + 9, 0xFFFFFFFF);
        int tw0 = textRenderer.getWidth("ДРЕВО НАВЫКОВ");
        ctx.drawTextWithShadow(textRenderer, "Очки: " + ClientState.points, px + 10 + tw0 + 16, py + 9, 0xFFFFD34D);

        btns.clear();
        int bx = px + pw - 8;
        bx = addBtn(bx, "Сброс", 0xFFB04040, () -> send("reset", ""));
        bx = addBtn(bx, "+1000", 0xFF3E8E5A, () -> send("points", "1000"));
        bx = addBtn(bx, "+100", 0xFF3E8E5A, () -> send("points", "100"));
        bx = addBtn(bx, "+10", 0xFF3E8E5A, () -> send("points", "10"));
        String lbl = "Выдать очки:";
        ctx.drawTextWithShadow(textRenderer, lbl, bx - textRenderer.getWidth(lbl) - 2, py + 10, 0xFFAAAAAA);
        for (Btn b : btns) {
            boolean hv = b.hit(mx, my);
            ctx.fill(b.x, b.y, b.x + b.w, b.y + b.h, hv ? b.color : mul(b.color & 0xFFFFFF, 0.6));
            ctx.drawBorder(b.x, b.y, b.w, b.h, 0xFF000000 | b.color);
            ctx.drawTextWithShadow(textRenderer, b.label, b.x + (b.w - textRenderer.getWidth(b.label)) / 2, b.y + 4, 0xFFFFFFFF);
        }

        // --- вкладки ---
        for (Branch br : Branch.values()) {
            int x = px + 8 + br.ordinal() * 104, y = py + 28, w = 100, h = 20;
            boolean sel = br == tab, hv = mx >= x && mx < x + w && my >= y && my < y + h;
            ctx.fill(x, y, x + w, y + h, sel ? mul(br.rgb, 0.5) : hv ? 0xFF2A2A3C : 0xFF1E1E2C);
            ctx.fill(x, y + h - 2, x + w, y + h, sel ? br.argb() : mul(br.rgb, 0.35));
            int have = 0, total = Skills.of(br).size();
            for (Skill s : Skills.of(br)) if (ClientState.unlocked.contains(s.id)) have++;
            String t = br.title + " " + have + "/" + total;
            ctx.drawTextWithShadow(textRenderer, t, x + (w - textRenderer.getWidth(t)) / 2, y + 6, sel ? 0xFFFFFFFF : 0xFFAAAAAA);
        }

        // --- дерево ---
        ctx.fill(tx, ty, tx + tw, ty + th, 0xFF0B0B13);
        ctx.enableScissor(tx, ty, tx + tw, ty + th);
        int gx0 = tx + (int) Math.floorMod((long) offX[tab.ordinal()], 24L);
        int gy0 = ty + (int) Math.floorMod((long) offY[tab.ordinal()], 24L);
        for (int gx = gx0; gx < tx + tw; gx += 24) ctx.fill(gx, ty, gx + 1, ty + th, 0x10FFFFFF);
        for (int gy = gy0; gy < ty + th; gy += 24) ctx.fill(tx, gy, tx + tw, gy + 1, 0x10FFFFFF);

        List<Skill> list = Skills.of(tab);
        for (Skill s : list) if (s.parent != null) drawLink(ctx, Skills.get(s.parent), s);
        for (Skill s : list) drawNode(ctx, s);
        ctx.disableScissor();
        ctx.drawBorder(tx, ty, tw, th, mul(tab.rgb, 0.45));

        // --- легенда ---
        int ly = ty + th + 7;
        legend(ctx, tx + 4, ly, tab.argb(), "Пассивный навык");
        legend(ctx, tx + 130, ly, 0xFFFFD34D, "Способность");
        legend(ctx, tx + 230, ly, 0xFFFF8A3D, "Оружие");
        String hint = "ЛКМ — изучить   |   Перетаскивание — двигать   |   K — закрыть";
        ctx.drawTextWithShadow(textRenderer, hint, tx + tw - textRenderer.getWidth(hint) - 2, ly, 0xFF777788);

        Skill hov = hovered(mx, my);
        if (hov != null) tooltip(ctx, hov, mx, my);
    }

    private int addBtn(int right, String label, int color, Runnable r) {
        int w = textRenderer.getWidth(label) + 12;
        int x = right - w;
        btns.add(new Btn(x, py + 5, w, 16, label, color, r));
        return x - 4;
    }

    private void legend(DrawContext ctx, int x, int y, int color, String text) {
        ctx.fill(x, y + 1, x + 6, y + 7, color);
        ctx.drawTextWithShadow(textRenderer, text, x + 10, y, 0xFFAAAAAA);
    }

    private void drawLink(DrawContext ctx, Skill a, Skill b) {
        int ax = nx(a), ay = ny(a), bx = nx(b), by = ny(b);
        boolean on = ClientState.unlocked.contains(b.id), mid = ClientState.unlocked.contains(a.id);
        int c = on ? tab.argb() : mid ? mul(tab.rgb, 0.5) : 0xFF2A2A38;
        int my = ay + SY / 2;
        if (ax == bx) vline(ctx, ax, ay, by, c);
        else { vline(ctx, ax, ay, my, c); hline(ctx, ax, bx, my, c); vline(ctx, bx, my, by, c); }
    }
    private static void vline(DrawContext c, int x, int y1, int y2, int col) { c.fill(x - 1, Math.min(y1, y2), x + 1, Math.max(y1, y2), col); }
    private static void hline(DrawContext c, int x1, int x2, int y, int col) { c.fill(Math.min(x1, x2), y - 1, Math.max(x1, x2) + 1, y + 1, col); }

    private void drawNode(DrawContext ctx, Skill s) {
        int x = nx(s), y = ny(s), h = NODE / 2;
        boolean un = ClientState.unlocked.contains(s.id);
        boolean av = !un && (s.parent == null || ClientState.unlocked.contains(s.parent));
        boolean afford = ClientState.points >= s.cost;
        int border = un ? tab.argb() : av ? (afford ? tab.argb() : 0xFF8A3A3A) : 0xFF333344;
        int fill = un ? mul(tab.rgb, 0.40) : av ? 0xFF1F1F2E : 0xFF14141C;
        if (un) ctx.fill(x - h - 2, y - h - 2, x + h + 2, y + h + 2, (0x45 << 24) | tab.rgb);
        ctx.fill(x - h, y - h, x + h, y + h, border);
        ctx.fill(x - h + 2, y - h + 2, x + h - 2, y + h - 2, fill);
        ctx.drawItem(s.stack(), x - 8, y - 8);

        ctx.getMatrices().push();
        ctx.getMatrices().translate(0, 0, 300);
        if (!un && !av) ctx.fill(x - h + 2, y - h + 2, x + h - 2, y + h - 2, 0xB00B0B13);
        if (s.ability != null) ctx.fill(x + h - 6, y - h + 1, x + h - 1, y - h + 6, 0xFFFFD34D);
        else if (s.grant != null) ctx.fill(x + h - 6, y - h + 1, x + h - 1, y - h + 6, 0xFFFF8A3D);
        if (!un) {
            String c = String.valueOf(s.cost);
            ctx.drawTextWithShadow(textRenderer, c, x + h - 3 - textRenderer.getWidth(c), y + h - 10, afford ? 0xFFFFE680 : 0xFFFF7070);
        }
        ctx.getMatrices().pop();
    }

    // ------------------------------------------------------------------ подсказка
    private List<String> wrap(String text, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String word : text.split(" ")) {
            String test = cur.length() == 0 ? word : cur + " " + word;
            if (textRenderer.getWidth(test) > maxW && cur.length() > 0) { out.add(cur.toString()); cur = new StringBuilder(word); }
            else cur = new StringBuilder(test);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private void tooltip(DrawContext ctx, Skill s, int mx, int my) {
        boolean un = ClientState.unlocked.contains(s.id);
        boolean av = !un && (s.parent == null || ClientState.unlocked.contains(s.parent));
        List<L> lines = new ArrayList<>();
        lines.add(new L(s.name, tab.argb()));
        if (s.ability != null) lines.add(new L("Способность (клавиша " + SkillTreeClient.CAST.getBoundKeyLocalizedText().getString() + ")", 0xFFFFD34D));
        else if (s.grant != null) lines.add(new L("Уникальное оружие", 0xFFFF8A3D));
        else lines.add(new L("Пассивный навык", 0xFFAAAAAA));
        for (String l : wrap(s.desc, 200)) lines.add(new L(l, 0xFFE0E0E0));
        if (s.ability != null) {
            Abilities.Ability a = Abilities.get(s.ability);
            if (a != null) lines.add(new L((a.mana() > 0 ? "Мана: " + a.mana() + ", " : "") + "перезарядка: " + SkillTreeClient.cdText(a.cooldown()) + " с", 0xFF9FD3FF));
        }
        lines.add(new L("", 0));
        if (un) {
            lines.add(new L("Изучено", 0xFF6BE08A));
            if (s.grant != null) lines.add(new L("Клик — получить предмет ещё раз", 0xFF999999));
        } else if (!av) {
            lines.add(new L("Требуется: " + Skills.get(s.parent).name, 0xFFFF7070));
            lines.add(new L("Стоимость: " + s.cost, 0xFF999999));
        } else if (ClientState.points >= s.cost) {
            lines.add(new L("Стоимость: " + s.cost + "  (клик — изучить)", 0xFF6BE08A));
        } else {
            lines.add(new L("Стоимость: " + s.cost + "  (не хватает очков)", 0xFFFF7070));
        }

        int w = 0;
        for (L l : lines) w = Math.max(w, textRenderer.getWidth(l.t));
        int h = lines.size() * 10 + 4;
        int x = mx + 12, y = my - 6;
        if (x + w + 8 > width) x = mx - w - 16;
        if (y + h + 4 > height) y = height - h - 6;

        ctx.getMatrices().push();
        ctx.getMatrices().translate(0, 0, 500);
        ctx.fill(x - 4, y - 4, x + w + 4, y + h, 0xF0100A1E);
        ctx.drawBorder(x - 4, y - 4, w + 8, h + 4, tab.argb());
        int yy = y;
        for (L l : lines) { ctx.drawTextWithShadow(textRenderer, l.t, x, yy, l.c); yy += 10; }
        ctx.getMatrices().pop();
    }

    // ------------------------------------------------------------------ ввод
    private void clickSound() {
        if (client != null) client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            for (Btn b : btns) if (b.hit(mx, my)) { clickSound(); b.run.run(); return true; }
            for (Branch br : Branch.values()) {
                int x = px + 8 + br.ordinal() * 104, y = py + 28;
                if (mx >= x && mx < x + 100 && my >= y && my < y + 20) { tab = br; lastTab = br; clickSound(); return true; }
            }
            Skill s = hovered(mx, my);
            if (s != null) {
                boolean un = ClientState.unlocked.contains(s.id);
                boolean av = !un && (s.parent == null || ClientState.unlocked.contains(s.parent));
                if ((un && s.grant != null) || (av && ClientState.points >= s.cost)) { clickSound(); send("unlock", s.id); }
                return true;
            }
        }
        if (inTree(mx, my)) { dragging = true; return true; }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            offX[tab.ordinal()] += dx; offY[tab.ordinal()] += dy;
            clampOffsets();
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) { dragging = false; return super.mouseReleased(mx, my, button); }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        offY[tab.ordinal()] += vAmount * 30;
        offX[tab.ordinal()] += hAmount * 30;
        clampOffsets();
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (SkillTreeClient.OPEN.matchesKey(keyCode, scanCode)) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
