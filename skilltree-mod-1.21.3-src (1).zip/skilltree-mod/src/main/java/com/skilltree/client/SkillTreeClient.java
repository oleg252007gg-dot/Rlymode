package com.skilltree.client;

import com.skilltree.Abilities;
import com.skilltree.Net;
import com.skilltree.Skill;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Locale;

public class SkillTreeClient implements ClientModInitializer {
    public static KeyBinding OPEN, CAST, NEXT, PREV;

    @Override
    public void onInitializeClient() {
        OPEN = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.skilltree.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "category.skilltree"));
        CAST = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.skilltree.cast", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.skilltree"));
        NEXT = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.skilltree.next", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.skilltree"));
        PREV = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.skilltree.prev", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.skilltree"));

        ClientPlayNetworking.registerGlobalReceiver(Net.SyncPayload.ID, (payload, context) -> ClientState.apply(payload));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientState.clear());
        ClientTickEvents.END_CLIENT_TICK.register(SkillTreeClient::tick);
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> hud(ctx));

        // кнопка «Древо навыков» в инвентаре
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof InventoryScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Древо навыков [K]"),
                        b -> client.setScreen(new SkillTreeScreen())).dimensions(6, 6, 116, 20).build());
            }
        });
    }

    private static void tick(MinecraftClient mc) {
        ClientState.tick++;
        boolean free = mc.player != null && mc.currentScreen == null;
        while (OPEN.wasPressed()) if (free) mc.setScreen(new SkillTreeScreen());
        List<Skill> list = ClientState.abilities();
        while (NEXT.wasPressed()) if (free && !list.isEmpty()) ClientState.selected = (ClientState.selected + 1) % list.size();
        while (PREV.wasPressed()) if (free && !list.isEmpty()) ClientState.selected = (ClientState.selected - 1 + list.size()) % list.size();
        while (CAST.wasPressed()) {
            if (!free) continue;
            if (list.isEmpty()) { mc.player.sendMessage(Text.literal("Нет изученных способностей — откройте древо [K]"), true); continue; }
            ClientState.selected = Math.floorMod(ClientState.selected, list.size());
            ClientPlayNetworking.send(new Net.ActionPayload("cast", list.get(ClientState.selected).ability));
        }
    }

    private static void hud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null || ClientState.unlocked.isEmpty()) return;
        TextRenderer tr = mc.textRenderer;
        int x = 8, y = 8, w = 140;
        List<Skill> list = ClientState.abilities();
        int h = list.isEmpty() ? 20 : 44;
        ctx.fill(x - 4, y - 4, x + w + 4, y + h, 0x90000000);
        ctx.drawBorder(x - 4, y - 4, w + 8, h + 4, 0x60B06BFF);

        ctx.drawTextWithShadow(tr, "Мана " + ClientState.mana + " / " + ClientState.maxMana, x, y, 0xFFC7B8FF);
        ctx.fill(x, y + 11, x + w, y + 16, 0xFF1A1030);
        int fw = (int) (w * ClientState.mana / (float) Math.max(1, ClientState.maxMana));
        ctx.fillGradient(x, y + 11, x + Math.min(w, fw), y + 16, 0xFF8A6CFF, 0xFF3D2BB0);

        if (!list.isEmpty()) {
            ClientState.selected = Math.floorMod(ClientState.selected, list.size());
            Skill s = list.get(ClientState.selected);
            Abilities.Ability a = Abilities.get(s.ability);
            int left = ClientState.cdLeft(s.ability);
            String label = "[" + CAST.getBoundKeyLocalizedText().getString() + "] " + s.name;
            ctx.drawTextWithShadow(tr, label, x, y + 21, left > 0 ? 0xFF999999 : 0xFFFFFFFF);
            if (a != null && a.cooldown() > 0) {
                ctx.fill(x, y + 32, x + w, y + 35, 0xFF222222);
                int cw = left > 0 ? (int) (w * (1.0 - left / (double) a.cooldown())) : w;
                ctx.fill(x, y + 32, x + Math.max(0, Math.min(w, cw)), y + 35, left > 0 ? 0xFFE0A030 : 0xFF4CD27A);
            }
        }
    }

    public static String cdText(int ticks) { return String.format(Locale.ROOT, "%.1f", ticks / 20.0); }
}
