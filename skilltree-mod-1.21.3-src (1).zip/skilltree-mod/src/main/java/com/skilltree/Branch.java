package com.skilltree;

public enum Branch {
    MAGIC("Магия", 0xB06BFF),
    COMBAT("Бой", 0xFF5A4D),
    GENERAL("Общее", 0x4CD27A);

    public final String title;
    public final int rgb;

    Branch(String title, int rgb) { this.title = title; this.rgb = rgb; }

    public int argb() { return 0xFF000000 | rgb; }
}
