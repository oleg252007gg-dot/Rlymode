package com.skilltree;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Вспомогательные методы для заклинаний: цели, урон, частицы, звуки. */
public final class Fx {
    private Fx() {}

    public static ServerWorld w(ServerPlayerEntity p) { return (ServerWorld) p.getWorld(); }
    public static void msg(ServerPlayerEntity p, String s) { p.sendMessage(Text.literal(s), true); }

    // ---------- множители силы ----------
    public static double sp(ServerPlayerEntity p) { return 1.0 + PlayerSkills.stat(p, Stat.SPELL_POWER); }
    public static double fire(ServerPlayerEntity p) { return sp(p) * (1.0 + PlayerSkills.stat(p, Stat.FIRE_POWER)); }
    public static double frost(ServerPlayerEntity p) { return sp(p) * (1.0 + PlayerSkills.stat(p, Stat.FROST_POWER)); }
    public static double atk(ServerPlayerEntity p) {
        var e = AttrUtil.get("attack_damage");
        return Math.max(2.0, e == null ? 2.0 : p.getAttributeValue(e));
    }

    // ---------- частицы и звуки ----------
    public static void particles(ServerWorld w, ParticleEffect t, Vec3d p, int n, double spread, double speed) {
        w.spawnParticles(t, p.x, p.y, p.z, n, spread, spread, spread, speed);
    }

    public static void ring(ServerWorld w, ParticleEffect t, Vec3d c, double r, int n, double y) {
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            w.spawnParticles(t, c.x + Math.cos(a) * r, c.y + y, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    public static void line(ServerWorld w, ParticleEffect t, Vec3d a, Vec3d b, double step) {
        Vec3d d = b.subtract(a);
        double len = d.length();
        if (len < 0.01) return;
        Vec3d n = d.multiply(1.0 / len);
        int count = 0;
        for (double s = 0; s <= len && count < 90; s += step, count++) {
            Vec3d q = a.add(n.multiply(s));
            w.spawnParticles(t, q.x, q.y, q.z, 1, 0, 0, 0, 0);
        }
    }

    public static void sound(ServerWorld w, Vec3d p, SoundEvent s, float vol, float pitch) {
        w.playSound(null, p.x, p.y, p.z, s, SoundCategory.PLAYERS, vol, pitch);
    }
    public static void sound(ServerWorld w, Vec3d p, RegistryEntry<SoundEvent> s, float vol, float pitch) {
        w.playSound(null, p.x, p.y, p.z, s.value(), SoundCategory.PLAYERS, vol, pitch);
    }

    // ---------- цели ----------
    public static boolean valid(ServerPlayerEntity p, Entity e) {
        if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) return false;
        if (e instanceof ArmorStandEntity || e instanceof MerchantEntity) return false;
        if (e instanceof TameableEntity t && t.isOwner(p)) return false;
        return true;
    }

    public static List<LivingEntity> around(ServerPlayerEntity p, Vec3d c, double r) {
        Box box = new Box(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r).expand(1.0);
        return w(p).getEntitiesByClass(LivingEntity.class, box, e -> valid(p, e)
                && e.getBoundingBox().getCenter().squaredDistanceTo(c) <= (r + e.getWidth() / 2) * (r + e.getWidth() / 2));
    }

    /** Точка, куда упирается взгляд (до блока), максимум range. */
    public static Vec3d rayEnd(ServerPlayerEntity p, double range) {
        HitResult hr = p.raycast(range, 1f, false);
        return hr.getType() == HitResult.Type.MISS ? p.getEyePos().add(p.getRotationVec(1f).multiply(range)) : hr.getPos();
    }

    /** Живые цели вдоль луча взгляда, ближайшие первыми. */
    public static List<LivingEntity> ray(ServerPlayerEntity p, double range, double grow, int max) {
        Vec3d eye = p.getEyePos();
        Vec3d end = rayEnd(p, range);
        Box box = new Box(eye, end).expand(grow + 1.0);
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : w(p).getEntitiesByClass(LivingEntity.class, box, x -> valid(p, x))) {
            Box bb = e.getBoundingBox().expand(grow);
            if (bb.contains(eye) || bb.raycast(eye, end).isPresent()) out.add(e);
        }
        out.sort(Comparator.comparingDouble(e -> e.squaredDistanceTo(eye)));
        return out.size() > max ? new ArrayList<>(out.subList(0, max)) : out;
    }

    /** Точка прицеливания; если взгляд в небо — опускается на землю. */
    public static Vec3d aim(ServerPlayerEntity p, double range) {
        HitResult hr = p.raycast(range, 1f, false);
        Vec3d pt = hr.getPos();
        if (hr.getType() == HitResult.Type.MISS) {
            BlockHitResult down = w(p).raycast(new RaycastContext(pt, pt.add(0, -40, 0),
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            if (down.getType() != HitResult.Type.MISS) pt = down.getPos();
        }
        return pt.add(0, 0.05, 0);
    }

    // ---------- урон ----------
    /** Магический урон (игнорирует броню, не вызывает боевые бонусы ближнего боя). */
    public static void magic(ServerPlayerEntity p, LivingEntity t, double dmg) {
        ServerWorld w = w(p);
        boolean prev = ServerLogic.busy;
        ServerLogic.busy = true;
        try {
            t.timeUntilRegen = 0;
            t.damage(w, w.getDamageSources().indirectMagic(p, p), (float) dmg);
        } finally { ServerLogic.busy = prev; }
    }

    /** Физический урон от имени игрока. */
    public static void phys(ServerPlayerEntity p, LivingEntity t, double dmg) {
        ServerWorld w = w(p);
        boolean prev = ServerLogic.busy;
        ServerLogic.busy = true;
        try {
            t.timeUntilRegen = 0;
            t.damage(w, w.getDamageSources().playerAttack(p), (float) dmg);
        } finally { ServerLogic.busy = prev; }
    }

    public static void push(LivingEntity e, Vec3d v) {
        e.addVelocity(v.x, v.y, v.z);
        e.velocityModified = true;
    }

    public static void pushAway(LivingEntity e, Vec3d from, double power, double up) {
        Vec3d d = e.getPos().subtract(from);
        Vec3d h = new Vec3d(d.x, 0, d.z);
        if (h.lengthSquared() < 1e-4) h = new Vec3d(0, 0, 1);
        h = h.normalize().multiply(power);
        push(e, new Vec3d(h.x, up, h.z));
    }

    /** Взрыв: частицы, звук, урон и отбрасывание. */
    public static void explode(ServerPlayerEntity p, Vec3d c, double r, double dmg, boolean fire) {
        ServerWorld w = w(p);
        particles(w, ParticleTypes.EXPLOSION, c, 3, r * 0.3, 0);
        particles(w, fire ? ParticleTypes.FLAME : ParticleTypes.CLOUD, c, 40, r * 0.35, 0.08);
        sound(w, c, SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, 1.2f, 0.9f);
        for (LivingEntity t : around(p, c, r)) {
            magic(p, t, dmg);
            if (fire) t.setOnFireFor(5);
            pushAway(t, c, 0.6, 0.35);
        }
    }
}
