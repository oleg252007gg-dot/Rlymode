package com.skilltree;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SkillTreeMod implements ModInitializer {
    public static final String MOD_ID = "skilltree";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    /** true = кнопка «Выдать очки» работает у всех игроков без каких-либо ограничений. */
    public static final boolean FREE_POINTS = true;

    /** Данные игрока (очки + изученные навыки) — сохраняются в мире и переживают смерть. */
    public static final AttachmentType<SkillData> DATA = AttachmentRegistry.<SkillData>create(
            Identifier.of(MOD_ID, "skills"),
            b -> b.persistent(SkillData.CODEC).copyOnDeath());

    @Override
    public void onInitialize() {
        ModItems.init();   // сначала предметы (они нужны навыкам)
        Skills.init();
        Abilities.init();
        Net.init();
        ServerLogic.init();
        LOG.info("Древо навыков загружено: {} навыков", Skills.ALL.size());
    }
}
